﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Книжный_магазин
{
    public partial class FormBooks : Form
    {
        string ConnStr = "@Data Source=DESKTOP-2HBUDMQ;Initial Catalog=Экзамен-ПМ.01-Смирнова;Integrated Security=True";
        int l = 0;
        public FormBooks()
        {
            InitializeComponent();
        }

        // Метод, для удобной обработки команды  UPDATE,
        // метод получает SQL-запрос
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn; // экземпляр класса типа SqlConnection
            SqlCommand cmd;

            // выделение памяти с инициализацией строки соединения с базой данных
            cn = new SqlConnection(ConnStr);
            cn.Open(); // открыть источник данных
            cmd = cn.CreateCommand(); // задать SQL-команду
            cmd.CommandText = SqlText; // задать командную строку
            cmd.ExecuteNonQuery(); // выполнить SQL-команду
            cn.Close(); // закрыть источник данных
        }

        public void FillBooks()
        {
           

            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Экзамен_ПМ_01_СмирноваDataSetKnigi.Книги". При необходимости она может быть перемещена или удалена.
            this.книгиTableAdapter.Fill(this._Экзамен_ПМ_01_СмирноваDataSetKnigi.Книги);

        }


        private void FormBooks_Load(object sender, EventArgs e)
        {
           
            FillBooks();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            // Выполняем запрос к базе данных
            con.Open();//открываем соединение
            string SqlText = "INSERT INTO [Книги] ([Код_книги],[Название],[Автор],[Жанр],[Описание],[Цена],[Количество_в_магазине],[Количество_на_складе])" + " VALUES(@Код_книги, @Название, @Автор, @Жанр,Описание, @Цена,@Количество_в_магазине,@Количество_на_складе)";
            SqlCommand dbCommand = new SqlCommand(SqlText, con);//команда
            dbCommand.Parameters.AddWithValue("@Код_книги", textBox1.Text);
            dbCommand.Parameters.AddWithValue("@Название", textBox2.Text);
            dbCommand.Parameters.AddWithValue("@Автор", textBox3.Text);
            dbCommand.Parameters.AddWithValue("@Жанр", textBox4.Text);
            dbCommand.Parameters.AddWithValue("@Описание", textBox5.Text);
            dbCommand.Parameters.AddWithValue("@Цена", textBox6.Text);
            dbCommand.Parameters.AddWithValue("@Количество_в_магазине", textBox7.Text);
            dbCommand.Parameters.AddWithValue("@Количество_на_складе", textBox8.Text);

            if (dbCommand.ExecuteNonQuery() != 1)
                MessageBox.Show("Ошибка выполнения запроса!", "Ошибка!");

            else
                MessageBox.Show("Данные добавлены!");
            FillBooks();

            // очистка данных из тест полей
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            string Код_книги, Название, Автор, Жанр, Описание, Цена, Количество_в_магазине, Количество_на_складе;

            int index, n;
            n = dataGridView1.Rows.Count;
            if (n == 1) return;
            index = dataGridView1.CurrentRow.Index;
            string idOk = dataGridView1[0, index].Value.ToString(); ;
            if (l == 0)
            {

                // заполнить форму данными перед открытием
                index = dataGridView1.CurrentRow.Index;
                Код_книги = dataGridView1[0, index].Value.ToString();
                Название = dataGridView1[1, index].Value.ToString();
                Автор = dataGridView1[2, index].Value.ToString();
                Жанр = dataGridView1[3, index].Value.ToString();
                Описание = dataGridView1[4, index].Value.ToString();
                Цена = dataGridView1[5, index].Value.ToString();
                Количество_в_магазине = dataGridView1[6, index].Value.ToString();
                Количество_на_складе = dataGridView1[7, index].Value.ToString();

                textBox1.Text = idOk;
                textBox2.Text = Название;
                textBox3.Text = Автор;
                textBox4.Text = Жанр;
                textBox5.Text = Описание;
                textBox6.Text = Цена;
                textBox7.Text = Количество_в_магазине;
                textBox8.Text = Количество_на_складе;

                l = 1;
            }
            else if (l == 1)
            {
                string SqlText = "UPDATE [Книги] set  Код_книги = \'" + textBox1.Text + "\',Название = \'" + textBox2.Text + "\',Автор = \'" + textBox3.Text + "\',Жанр = \'" + textBox4.Text + "\',Описание =\'" + textBox5.Text + "\',Цена=\'" + textBox6.Text + "\',Количество_в_магазине=\'"+ textBox7.Text+ "\',Количество_на_складе=\'"+ textBox8.Text + "\'" + " where Код_книги = " + idOk; 
                MyExecuteNonQuery(SqlText);
                FillBooks();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                l = 0;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Проверяем количество выбранных строк
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Выберите одну строку для удаления!", "Сообщение!");
                return;
            }
            // Запомним выбранную строку
            int index = dataGridView1.SelectedRows[0].Index;

            //Проверим данные в таблице
            if (dataGridView1.Rows[index].Cells[0].Value == null)
            {
                MessageBox.Show("Не все данные введены!", "Сообщение!");
                return;
            }

            //Считаем данные
            string id = dataGridView1.Rows[index].Cells[0].Value.ToString();

            SqlConnection con = new SqlConnection(ConnStr);
            // Выполняем запрос к базе данных
            con.Open();//открываем соединение
            string SqlText = "DELETE FROM [Книги] WHERE Код_книги=" + id;//строка запроса
            SqlCommand dbCommand = new SqlCommand(SqlText, con);//команда

            //Выполняем запрос
            if (dbCommand.ExecuteNonQuery() != 1)

                MessageBox.Show("Ошибка выполнения запроса!", "Ошибка!");
            else
                MessageBox.Show("Данные удалены !", "Сообщение!");
            // Удаляем данные из таблицы в форме

            dataGridView1.Rows.RemoveAt(index);
            //Закрываем соединение с БД
            con.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormGlav formGlav = new FormGlav();
            formGlav.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormZakazy FormZakazy = new FormZakazy();
            FormZakazy.Show();
        }
    }
}
