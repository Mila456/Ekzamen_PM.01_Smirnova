﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Книжный_магазин
{
    public partial class FormZakazy : Form
    {
        string ConnStr = "@Data Source=DESKTOP-2HBUDMQ;Initial Catalog=Экзамен-ПМ.01-Смирнова;Integrated Security=True";
        int l = 0;
        public FormZakazy()
        {
            InitializeComponent();
        }

        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn; // экземпляр класса типа SqlConnection
            SqlCommand cmd;

            // выделение памяти с инициализацией строки соединения с базой данных
            cn = new SqlConnection(ConnStr);
            cn.Open(); // открыть источник данных
            cmd = cn.CreateCommand(); // задать SQL-команду
            cmd.CommandText = SqlText; // задать командную строку
            cmd.ExecuteNonQuery(); // выполнить SQL-команду
            cn.Close(); // закрыть источник данных
        }

        public void FillZakazy()
        {


            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Экзамен_ПМ_01_СмирноваDataSetZakazi.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this._Экзамен_ПМ_01_СмирноваDataSetZakazi.Заказы);

        }

        private void FormZakazy_Load(object sender, EventArgs e)
        {
            
            FillZakazy();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            // Выполняем запрос к базе данных
            con.Open();//открываем соединение
            string SqlText = "INSERT INTO [Заказы] ([Номер_заказа],[Дата],[Код_клиента],[Код_книги],[Количество],[Стоимость])" + " VALUES(@Номер_заказа, @Дата, @Код_клиента, @Код_книги,@Количество, @Стоимость)";
            SqlCommand dbCommand = new SqlCommand(SqlText, con);//команда
            dbCommand.Parameters.AddWithValue("@Номер_заказа", textBox1.Text);
            dbCommand.Parameters.AddWithValue("@Дата", textBox2.Text);
            dbCommand.Parameters.AddWithValue("@Код_клиента", textBox3.Text);
            dbCommand.Parameters.AddWithValue("@Код_книги", textBox4.Text);
            dbCommand.Parameters.AddWithValue("@Количество", textBox5.Text);
            dbCommand.Parameters.AddWithValue("@Стоимость", textBox6.Text);
           
           

            if (dbCommand.ExecuteNonQuery() != 1)
                MessageBox.Show("Ошибка выполнения запроса!", "Ошибка!");

            else
                MessageBox.Show("Данные добавлены!");
            FillZakazy();

            // очистка данных из тест полей
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string Номер_заказа, Дата, Код_клиента, Код_книги, Количество, Стоимость;

            int index, n;
            n = dataGridView1.Rows.Count;
            if (n == 1) return;
            index = dataGridView1.CurrentRow.Index;
            string idOk = dataGridView1[0, index].Value.ToString(); ;
            if (l == 0)
            {

                // заполнить форму данными перед открытием
                index = dataGridView1.CurrentRow.Index;
                Номер_заказа = dataGridView1[0, index].Value.ToString();
                Дата = dataGridView1[1, index].Value.ToString();
                Код_клиента = dataGridView1[2, index].Value.ToString();
                Код_книги = dataGridView1[3, index].Value.ToString();
                Количество = dataGridView1[4, index].Value.ToString();
                Стоимость = dataGridView1[5, index].Value.ToString();

                textBox1.Text = idOk;
                textBox2.Text = Дата;
                textBox3.Text = Код_клиента;
                textBox4.Text = Код_книги;
                textBox5.Text = Количество;
                textBox6.Text = Стоимость;

                l = 1;
            }
            else if (l == 1)
            {
                string SqlText = "UPDATE [Заказы] set   Номер_заказа = \'" + textBox1.Text + "\',Дата= \'" + textBox2.Text + "\',Код_клиента= \'" + textBox3.Text + "\',Код_книги= \'" + textBox4.Text + "\',Количество =\'" + textBox5.Text + "\', Стоимость =\'" + textBox6.Text + "\'" + " where  Номер_заказа = " + idOk;
                MyExecuteNonQuery(SqlText);
                FillZakazy();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                l = 0;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Выберите одну строку для удаления!", "Сообщение!");
                return;
            }
            // Запомним выбранную строку
            int index = dataGridView1.SelectedRows[0].Index;

            //Проверим данные в таблице
            if (dataGridView1.Rows[index].Cells[0].Value == null)
            {
                MessageBox.Show("Не все данные введены!", "Сообщение!");
                return;
            }

            //Считаем данные
            string id = dataGridView1.Rows[index].Cells[0].Value.ToString();

            SqlConnection con = new SqlConnection(ConnStr);
            // Выполняем запрос к базе данных
            con.Open();//открываем соединение
            string SqlText = "DELETE FROM [Заказы] WHERE Номер_заказа=" + id;//строка запроса
            SqlCommand dbCommand = new SqlCommand(SqlText, con);//команда

            //Выполняем запрос
            if (dbCommand.ExecuteNonQuery() != 1)

                MessageBox.Show("Ошибка выполнения запроса!", "Ошибка!");
            else
                MessageBox.Show("Данные удалены !", "Сообщение!");
            // Удаляем данные из таблицы в форме

            dataGridView1.Rows.RemoveAt(index);
            //Закрываем соединение с БД
            con.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormGlav formGlav = new FormGlav();
            formGlav.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormBooks FormBooks = new FormBooks();
            FormBooks.Show();
        }
    }
}
